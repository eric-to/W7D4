class Api::ItemsController < ApplicationController
  def index
  end
end